 $(".swap").on("click", function() {
 	
 });
 $(function(){
    $('.android').hover(
    function(){
        $('.mask1').css('opacity', '1');
        $('.mask2').css('opacity', '0');
        $('.ios_container').css('z-index', '0');
        $('.android_container').css('z-index', '999');
    },
    function() {
    	$('.mask1').css('opacity', '0');
    	$('.mask2').css('opacity', '1');
        $('.ios_container').css('z-index', '999');
        $('.android_container').css('z-index', '0');
	}
    )
});
 $(function(){
    $('header').hover(
    function(){
        if ($('.ios').hasClass('disabled')) {
            $('.mask2').css('opacity', '0');
            $('.mask1').css('opacity', '1');
        }
    },
    function() {
        $('.mask2').css('opacity', '1');
            $('.mask1').css('opacity', '0');
    }
    )
});
  $(".android").on("click", function() {
        $('.android').css('left', '10%');
        $('.ios').addClass('disabled');
        $('.android').removeClass('disabled');
        $('.ios_title').css('opacity','1');
        $('.android_title').css('opacity','0');
        $('.menu_link').css('color','#fff');
        $('.logo').css('filter', 'invert(1)');
        $('.android_arrow').fadeOut(200);
 });
  $(".ios").on("click", function() {
        $('.android').css('left', '90%');
        $('.android').addClass('disabled');
        $('.ios').removeClass('disabled');
        $('.ios_title').css('opacity','0');
        $('.android_title').css('opacity','1');
        $('.menu_link').css('color','#000');
        $('.logo').css('filter', 'invert(0)');
        $('.android_arrow').fadeIn(200);
 });
   $(function(){
        $(".iphone5").on("click", function() {
            console.log("1");
            // $('.content').empty();
            $('.content').load( "iphones.html #i5" );
        });
        $(".iphone5s").on("click", function() {
            console.log("2");
            // $('.content').empty();
            $('.content').load( "iphones.html #i6" );
        });
    });